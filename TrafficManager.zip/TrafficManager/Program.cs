﻿using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using System;
using System.Configuration;

using System.Text;
using System.Threading.Tasks;

namespace TrafficManager
{
    class Program
    {

        //const int VehicleThreshold =2;
        static readonly Random Rnd = new Random();
        static string DeviceConnectionString = ConfigurationManager.AppSettings["DeviceConnectionStr1"];

        static int SecTime = 300;
        static string deviceId = "";


        static void Main(string[] args)
        {
            int id = Convert.ToInt32(args[0]);
            deviceId = "Device" + id;

            switch (id)
            {
                case 1:
                    DeviceConnectionString = ConfigurationManager.AppSettings["DeviceConnectionStr1"];
                    break;
                case 2:
                    DeviceConnectionString = ConfigurationManager.AppSettings["DeviceConnectionStr2"];
                    break;
                case 3:
                    DeviceConnectionString = ConfigurationManager.AppSettings["DeviceConnectionStr3"];
                    break;
                case 4:
                    DeviceConnectionString = ConfigurationManager.AppSettings["DeviceConnectionStr4"];
                    break;
                default:
                    DeviceConnectionString = ConfigurationManager.AppSettings["DeviceConnectionStr1"];
                    break;
            }

            Console.WriteLine("Creating device client from connection string\n");

            DeviceClient deviceClient = DeviceClient.CreateFromConnectionString(DeviceConnectionString);
            if (deviceClient == null)
            {
                Console.WriteLine("Failed to create DeviceClient!");
                return;
            }


            Console.WriteLine("IoT Hub Quickstarts #1 - Simulated device. Ctrl-C to exit.\n");

            // Connect to the IoT hub using the MQTT protocol   
            // Signal coming from EdgeDevice set
            deviceClient.SetMethodHandlerAsync("reset", ResetCallback, null).Wait();

            SendEvents(deviceClient, SecTime).Wait();

            Console.WriteLine("Exiting!\n");

            //Console.ReadLine();


        }


        public static Task<MethodResponse> ResetCallback(MethodRequest methodRequest, object userContext)
        {
            var data = Encoding.UTF8.GetString(methodRequest.Data);
            Console.Write(data);
            return Task.FromResult(new MethodResponse(200));
        }



        static async Task SendEvents(DeviceClient deviceClient, int SecTime)
        {
            Random rnd = new Random();
            Console.WriteLine("Total number of vehicle per second is...\n", SecTime);
            try
            {
                for (int count = 0; count < SecTime; count++)
                {
                    await Task.Delay(1000);
                    var VehicleData = new MessageBody
                    {
                        DeviceId = deviceId,
                        VehicleCount = Rnd.Next(5, 20),
                        QueueCount = Rnd.Next(100, 500),
                        TimeCreated = DateTime.UtcNow
                    };

                    string dataBuffer = JsonConvert.SerializeObject(VehicleData);
                    Message eventMessage = new Message(Encoding.UTF8.GetBytes(dataBuffer));
                    //eventMessage.Properties.Add("TrafficData", (VehicleData.VehicleCount > VehicleThreshold) ? "true" : "false");

                    Console.WriteLine("\t{0}> Sending message: {1}, Data: [{2}]", DateTime.Now.ToLocalTime(), count, dataBuffer);

                    await deviceClient.SendEventAsync(eventMessage).ConfigureAwait(false);
                    // await deviceClient1.SendEventAsync(eventMessage).ConfigureAwait(false);
                    await Task.Delay(10000);

                   
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception" + ex.Message);
            }
        }
    }

    public class MessageBody
    {
        [JsonProperty(PropertyName = "DeviceId")]
        public string DeviceId { get; set; }

        [JsonProperty(PropertyName = "VehicleCount")]
        public int VehicleCount { get; set; }

        [JsonProperty(PropertyName = "Queue")]
        public int QueueCount { get; set; }

        [JsonProperty(PropertyName = "time")]
        public DateTime TimeCreated { get; set; }
    }
}
